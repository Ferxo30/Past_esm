# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class PasteleriaCakeFraction(models.Model):
    _name = "pasteleria.cake.fraction"
    _description = "Fraccionamiento de pasteles"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date desc, id desc"

    name = fields.Char(string="Referencia", required=True, copy=False, default="New", tracking=True)
    active = fields.Boolean(default=True)
    state = fields.Selection([
        ("draft", "Borrador"),
        ("done", "Realizado"),
        ("reversed", "Revertido"),
        ("cancel", "Cancelado"),
    ], default="draft", tracking=True)
    date = fields.Datetime(string="Fecha", default=fields.Datetime.now, required=True, tracking=True)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, required=True)
    user_id = fields.Many2one("res.users", string="Usuario", default=lambda self: self.env.user, required=True, tracking=True)

    source_origin = fields.Selection([
        ("backend", "Backend"),
        ("pos", "POS"),
        ("pasteleria_view", "Vista pastelerías"),
    ], string="Origen", default="backend", required=True, tracking=True)

    pos_config_id = fields.Many2one("pos.config", string="Punto de venta", tracking=True)
    pos_session_id = fields.Many2one("pos.session", string="Sesión POS", tracking=True)
    warehouse_id = fields.Many2one("stock.warehouse", string="Almacén", required=True, tracking=True)
    location_id = fields.Many2one("stock.location", string="Ubicación origen/destino", required=True, tracking=True)
    virtual_fraction_location_id = fields.Many2one(
        "stock.location",
        string="Ubicación virtual de fraccionamiento",
        required=True,
        default=lambda self: self._default_virtual_fraction_location(),
        help="Ubicación virtual intermedia para dejar trazabilidad de salida/entrada.",
    )

    full_product_id = fields.Many2one(
        "product.product",
        string="Pastel completo",
        required=True,
        domain=[("can_be_fraction_source", "=", True)],
        tracking=True,
    )
    slice_product_id = fields.Many2one(
        "product.product",
        string="Producto porción",
        required=True,
        domain=[("is_cake_slice", "=", True)],
        tracking=True,
    )

    qty_full = fields.Float(string="Cantidad de enteros", default=1.0, required=True, tracking=True)
    qty_slices_created = fields.Float(string="Porciones generadas", required=True, tracking=True)

    reason_id = fields.Many2one("pasteleria.cake.fraction.reason", string="Motivo", tracking=True)
    note = fields.Text(string="Observaciones")

    expected_slice_min = fields.Integer(related="full_product_id.expected_slice_min", string="Sugerido mín.")
    expected_slice_max = fields.Integer(related="full_product_id.expected_slice_max", string="Sugerido máx.")
    warning_message = fields.Char(string="Advertencia", compute="_compute_warning_message")

    consumption_move_id = fields.Many2one("stock.move", string="Movimiento salida", copy=False)
    production_move_id = fields.Many2one("stock.move", string="Movimiento entrada", copy=False)
    reverse_of_id = fields.Many2one("pasteleria.cake.fraction", string="Revierte a", copy=False)
    reversal_fraction_id = fields.Many2one("pasteleria.cake.fraction", string="Reversión generada", copy=False)

    full_available_qty = fields.Float(string="Disponibilidad entero", compute="_compute_full_available_qty")
    can_reverse = fields.Boolean(compute="_compute_can_reverse")

    @api.model
    def _default_virtual_fraction_location(self):
        location = self.env.ref("pasteleria_pos_fraccionamiento.stock_location_cake_fraction_virtual", raise_if_not_found=False)
        return location.id if location else False

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "New") == "New":
                vals["name"] = self.env["ir.sequence"].next_by_code("pasteleria.cake.fraction") or "New"
            if vals.get("pos_config_id") and not vals.get("warehouse_id"):
                pos_config = self.env["pos.config"].browse(vals["pos_config_id"])
                warehouse = pos_config.picking_type_id.warehouse_id
                vals["warehouse_id"] = warehouse.id
                vals["location_id"] = warehouse.lot_stock_id.id
        records = super().create(vals_list)
        return records

    @api.depends("full_product_id", "location_id")
    def _compute_full_available_qty(self):
        Quant = self.env["stock.quant"].sudo()
        for rec in self:
            rec.full_available_qty = 0.0
            if rec.full_product_id and rec.location_id:
                rec.full_available_qty = Quant._get_available_quantity(rec.full_product_id, rec.location_id, allow_negative=False)

    @api.depends("state", "reversal_fraction_id")
    def _compute_can_reverse(self):
        for rec in self:
            rec.can_reverse = rec.state == "done" and not rec.reversal_fraction_id

    @api.depends("qty_slices_created", "expected_slice_min", "expected_slice_max")
    def _compute_warning_message(self):
        for rec in self:
            warning = False
            if rec.qty_slices_created and rec.expected_slice_min and rec.qty_slices_created < rec.expected_slice_min:
                warning = _("La cantidad de porciones es menor al mínimo sugerido (%s).") % rec.expected_slice_min
            elif rec.qty_slices_created and rec.expected_slice_max and rec.qty_slices_created > rec.expected_slice_max:
                warning = _("La cantidad de porciones es mayor al máximo sugerido (%s).") % rec.expected_slice_max
            rec.warning_message = warning

    @api.onchange("pos_config_id")
    def _onchange_pos_config_id(self):
        if self.pos_config_id:
            warehouse = self.pos_config_id.picking_type_id.warehouse_id
            self.warehouse_id = warehouse
            self.location_id = warehouse.lot_stock_id

    @api.onchange("full_product_id")
    def _onchange_full_product_id(self):
        if self.full_product_id:
            self.slice_product_id = self.full_product_id.cake_slice_product_id

    @api.constrains("full_product_id", "slice_product_id")
    def _check_same_template(self):
        for rec in self:
            if rec.full_product_id and rec.slice_product_id and rec.full_product_id.product_tmpl_id != rec.slice_product_id.product_tmpl_id:
                raise ValidationError(_("El pastel completo y la porción deben pertenecer al mismo producto plantilla."))

    @api.constrains("qty_full", "qty_slices_created")
    def _check_quantities(self):
        for rec in self:
            if rec.qty_full <= 0:
                raise ValidationError(_("La cantidad de enteros debe ser mayor a cero."))
            if rec.qty_slices_created <= 0:
                raise ValidationError(_("La cantidad de porciones debe ser mayor a cero."))

    @api.constrains("full_product_id", "slice_product_id")
    def _check_product_flags(self):
        for rec in self:
            if rec.full_product_id and not rec.full_product_id.can_be_fraction_source:
                raise ValidationError(_("El producto origen debe estar marcado como fraccionable."))
            if rec.slice_product_id and not rec.slice_product_id.is_cake_slice:
                raise ValidationError(_("El producto destino debe estar marcado como porción."))

    def _check_before_confirm(self):
        self.ensure_one()
        if self.state != "draft":
            raise UserError(_("Solo se pueden confirmar fraccionamientos en borrador."))
        if not self.location_id:
            raise UserError(_("Debe definir una ubicación interna."))
        if self.location_id.usage != "internal":
            raise UserError(_("La ubicación principal del fraccionamiento debe ser interna."))
        available = self.env["stock.quant"].sudo()._get_available_quantity(self.full_product_id, self.location_id, allow_negative=False)
        if available < self.qty_full:
            raise UserError(_("No hay stock suficiente del pastel completo en la ubicación seleccionada."))

    def _prepare_move_vals(self, product, quantity, location_id, location_dest_id, reference_name):
        self.ensure_one()
        return {
            "name": reference_name,
            "company_id": self.company_id.id,
            "product_id": product.id,
            "product_uom": product.uom_id.id,
            "product_uom_qty": quantity,
            "quantity": quantity,
            "location_id": location_id.id,
            "location_dest_id": location_dest_id.id,
            "state": "draft",
            "origin": self.name,
            "reference": self.name,
        }

    def _action_do_move(self, vals):
        move = self.env["stock.move"].create(vals)
        move._action_confirm()
        move._action_assign()
        move.quantity = vals["product_uom_qty"]
        move._action_done()
        return move

    def action_confirm(self):
        for rec in self:
            rec._check_before_confirm()
            consumption_vals = rec._prepare_move_vals(
                rec.full_product_id,
                rec.qty_full,
                rec.location_id,
                rec.virtual_fraction_location_id,
                _("Salida por fraccionamiento %s") % rec.name,
            )
            production_vals = rec._prepare_move_vals(
                rec.slice_product_id,
                rec.qty_slices_created,
                rec.virtual_fraction_location_id,
                rec.location_id,
                _("Entrada por fraccionamiento %s") % rec.name,
            )
            rec.consumption_move_id = rec._action_do_move(consumption_vals)
            rec.production_move_id = rec._action_do_move(production_vals)
            rec.state = "done"
        return True

    def action_cancel(self):
        for rec in self:
            if rec.state != "draft":
                raise UserError(_("Solo se pueden cancelar registros en borrador."))
            rec.state = "cancel"
        return True

    def action_reset_to_draft(self):
        for rec in self:
            if rec.state != "cancel":
                raise UserError(_("Solo se puede restablecer a borrador un registro cancelado."))
            rec.state = "draft"
        return True

    def action_reverse(self):
        reversed_records = self.env["pasteleria.cake.fraction"]
        for rec in self:
            if rec.state != "done":
                raise UserError(_("Solo se pueden revertir fraccionamientos realizados."))
            if rec.reversal_fraction_id:
                raise UserError(_("Este fraccionamiento ya cuenta con una reversión."))
            available_slice_qty = self.env["stock.quant"].sudo()._get_available_quantity(rec.slice_product_id, rec.location_id, allow_negative=False)
            if available_slice_qty < rec.qty_slices_created:
                raise UserError(_("No hay suficientes porciones disponibles para revertir el fraccionamiento."))

            reverse = self.create({
                "source_origin": rec.source_origin,
                "pos_config_id": rec.pos_config_id.id,
                "pos_session_id": rec.pos_session_id.id,
                "warehouse_id": rec.warehouse_id.id,
                "location_id": rec.location_id.id,
                "virtual_fraction_location_id": rec.virtual_fraction_location_id.id,
                "full_product_id": rec.full_product_id.id,
                "slice_product_id": rec.slice_product_id.id,
                "qty_full": rec.qty_full,
                "qty_slices_created": rec.qty_slices_created,
                "reason_id": rec.reason_id.id,
                "note": _("Reversión automática de %s") % rec.name,
                "reverse_of_id": rec.id,
            })
            reverse._execute_reversal_moves()
            rec.reversal_fraction_id = reverse.id
            rec.state = "reversed"
            reversed_records |= reverse
        action = self.env.ref("pasteleria_pos_fraccionamiento.action_pasteleria_cake_fraction")
        return {
            "type": "ir.actions.act_window",
            "name": action.name,
            "res_model": "pasteleria.cake.fraction",
            "view_mode": "tree,form",
            "domain": [("id", "in", reversed_records.ids)],
        }

    def _execute_reversal_moves(self):
        self.ensure_one()
        slice_out_vals = self._prepare_move_vals(
            self.slice_product_id,
            self.qty_slices_created,
            self.location_id,
            self.virtual_fraction_location_id,
            _("Salida por reversión %s") % self.name,
        )
        full_in_vals = self._prepare_move_vals(
            self.full_product_id,
            self.qty_full,
            self.virtual_fraction_location_id,
            self.location_id,
            _("Entrada por reversión %s") % self.name,
        )
        self.consumption_move_id = self._action_do_move(slice_out_vals)
        self.production_move_id = self._action_do_move(full_in_vals)
        self.state = "done"

    @api.model
    def create_fraction_from_pos(self, payload):
        pos_session = self.env["pos.session"].browse(payload.get("pos_session_id"))
        if not pos_session:
            raise UserError(_("No se encontró la sesión POS para registrar el fraccionamiento."))
        pos_config = pos_session.config_id
        warehouse = pos_config.picking_type_id.warehouse_id
        full_product = self.env["product.product"].browse(payload.get("full_product_id"))
        if not full_product:
            raise UserError(_("Debe indicar el pastel completo a fraccionar."))
        slice_product = full_product.cake_slice_product_id
        if not slice_product:
            raise UserError(_("La variante seleccionada no tiene porción configurada."))

        record = self.create({
            "source_origin": "pos",
            "pos_config_id": pos_config.id,
            "pos_session_id": pos_session.id,
            "warehouse_id": warehouse.id,
            "location_id": warehouse.lot_stock_id.id,
            "full_product_id": full_product.id,
            "slice_product_id": slice_product.id,
            "qty_full": payload.get("qty_full", 1),
            "qty_slices_created": payload.get("qty_slices_created", 0),
            "reason_id": payload.get("reason_id"),
            "note": payload.get("note"),
        })
        record.action_confirm()
        return {
            "fraction_id": record.id,
            "name": record.name,
            "slice_product_id": record.slice_product_id.id,
            "qty_slices_created": record.qty_slices_created,
        }
