# -*- coding: utf-8 -*-
{
    "name": "Pastelería POS - Fraccionamiento de pasteles",
    "version": "18.0.1.0.0",
    "summary": "Fraccionamiento controlado de pasteles completos a porciones",
    "category": "Point of Sale",
    "author": "OpenAI",
    "license": "LGPL-3",
    "depends": [
        "point_of_sale",
        "stock",
        "product",
    ],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "data/sequence_data.xml",
        "views/product_product_views.xml",
        "views/cake_fraction_reason_views.xml",
        "views/cake_fraction_views.xml",
        "views/menu_views.xml",
    ],
    "assets": {
        "point_of_sale._assets_pos": [
            "pasteleria_pos_fraccionamiento/static/src/js/pos_fraction_button.js",
            "pasteleria_pos_fraccionamiento/static/src/js/fraction_popup.js",
            "pasteleria_pos_fraccionamiento/static/src/xml/fraction_popup.xml",
            "pasteleria_pos_fraccionamiento/static/src/scss/fraction_popup.scss",
        ],
    },
    "installable": True,
    "application": False,
}
