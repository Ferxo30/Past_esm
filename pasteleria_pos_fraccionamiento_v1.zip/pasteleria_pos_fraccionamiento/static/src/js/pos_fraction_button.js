/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { patch } from "@web/core/utils/patch";

patch(ProductScreen.prototype, {
    setup() {
        super.setup();
        this.pos = usePos();
    },

    async onClickCakeFraction() {
        const line = this.currentOrder?.get_selected_orderline();
        if (!line) {
            this.dialog.add(this.constructor.components.ErrorPopup || null, {
                title: _t("Fraccionamiento"),
                body: _t("Selecciona primero una línea con el pastel completo que quieres fraccionar."),
            });
            return;
        }
        const product = line.get_product();
        if (!product || !product.can_be_fraction_source) {
            this.dialog.add(this.constructor.components.ErrorPopup || null, {
                title: _t("Fraccionamiento"),
                body: _t("La línea seleccionada no corresponde a un pastel completo fraccionable."),
            });
            return;
        }
        this.dialog.add(this.env.services.popup.get("CakeFractionPopup"), {
            product,
        });
    },
});
