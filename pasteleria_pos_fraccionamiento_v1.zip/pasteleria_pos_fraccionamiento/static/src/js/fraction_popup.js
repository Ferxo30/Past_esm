/** @odoo-module **/

import { Component, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";

export class CakeFractionPopup extends Component {
    static template = "pasteleria_pos_fraccionamiento.CakeFractionPopup";
    static components = { Dialog };
    static props = ["close", "product"];

    setup() {
        this.pos = usePos();
        this.orm = useService("orm");
        this.notification = useService("notification");
        this.state = useState({
            qty_full: 1,
            qty_slices_created: 0,
            note: "",
        });
    }

    async confirm() {
        if (!this.state.qty_full || !this.state.qty_slices_created) {
            this.notification.add(_t("Debes indicar enteros y porciones generadas."), { type: "danger" });
            return;
        }
        try {
            const result = await this.orm.call(
                "pasteleria.cake.fraction",
                "create_fraction_from_pos",
                [{
                    pos_session_id: this.pos.pos_session.id,
                    full_product_id: this.props.product.id,
                    qty_full: Number(this.state.qty_full),
                    qty_slices_created: Number(this.state.qty_slices_created),
                    note: this.state.note,
                }]
            );
            this.notification.add(_t("Fraccionamiento registrado: %s", result.name), { type: "success" });
            this.props.close();
        } catch (error) {
            this.notification.add(error.message || _t("No se pudo registrar el fraccionamiento."), { type: "danger" });
        }
    }
}

registry.category("popups").add("CakeFractionPopup", CakeFractionPopup);
